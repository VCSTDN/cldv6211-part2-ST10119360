USE master;
GO
IF NOT EXISTS (
SELECT name
FROM sys.databases
WHERE name = N'CLDV6211_PART_2_ST10119360_Joshua Brown'
)
CREATE DATABASE [CLDV6211_PART_2_ST10119360_Joshua Brown]
GO

--------QUESTION 1---------
CREATE TABLE Inspectors(
	InspectNO VARCHAR(4) NOT NULL PRIMARY KEY,
	InspectName VARCHAR(150) NOT NULL,
	InspectEmail VARCHAR(200) NOT NULL,
	InspectMobile INT NOT NULL)

CREATE TABLE Car(
	CarNo VARCHAR(6) NOT NULL PRIMARY KEY,
	CarMake VARCHAR(50) NOT NULL,
	CarModel VARCHAR(150) NOT NULL,
	KmTrav INT NOT NULL,
	KmServ INT NOT NULL,
	Avalaible VARCHAR(3) NOT NULL
	)

CREATE TABLE Driver(
	DriverID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	DriverName VARCHAR(150) NOT NULL,
	DriverAddress VARCHAR(300) Not Null,
	DriverEmail VARCHAR(200) NOT NULL,
	DriverMobile INT NOT NULL
 )

 CREATE TABLE ReturnCars(
	ReturnNo INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	ReturnDate INT NOT NULL,
	ElapsedDate INT NOT NULL,
	Fine INT NOT NULL,
	CarNo VARCHAR(6),
	InspectNO VARCHAR(4),
	DriverID INT,
	FOREIGN KEY(CarNo) REFERENCES Car(CarNo),
	FOREIGN KEY(InspectNO) REFERENCES Inspectors(InspectNO),
	FOREIGN KEY(DriverID) REFERENCES Driver(DriverID)
	)

	CREATE TABLE Rentals(
	RentalNo INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
	StartDate INT NOT NULL,
	EndDate INT NOT NULL,
	RentalFee INT NOT NULL,
	CarNo VARCHAR(6),
	InspectNO VARCHAR(4),
	DriverID INT,
	FOREIGN KEY(CarNo) REFERENCES Car(CarNo),
	FOREIGN KEY(InspectNO) REFERENCES Inspectors(InspectNO),
	FOREIGN KEY(DriverID) REFERENCES Driver(DriverID)
	)


	
	------QUESTION 2---------
INSERT INTO Inspectors(InspectNO,InspectName,InspectEmail,InspectMobile)
VALUES('I101','Bud Barnes','bud@therideyourent.com',0821585359),
	  ('I102','Tracy Reeves','tracy@therideyourent.com',0822889988),
	  ('I103','Sandra Goodwin','sandra@therideyourent.com',0837698468),
	  ('I104','Shannon Burke','shannon@therideyourent.com',0836802514);

	  SELECT * FROM Rentals;

INSERT INTO Car(CarNo,CarMake,CarModel,KmTrav,KmServ,Avalaible)
VALUES('HYU001','Hyundai','Grand i10 1.0 Motion',1500,15000,'yes'),
	  ('HYU002','Hyundai','i20 1.2 Fluid',3000,15000,'yes'),
	  ('BMW001','BMW','320d 1.2',20000,50000,'yes'),
	  ('BMW002','BMW','240d 1.4',9500,15000,'yes'),
	  ('TOY001','Toyota','Corolloa 1.0',15000,50000,'yes'),
	  ('TOY002','Toyota','Avanza 1.0',98000,15000,'yes'),
	  ('TOY003','Toyota','Corolla Quest 1.0',15000,50000,'yes'),
	  ('MER001','Mercedes Benz','c180',5200,15000,'yes'),
	  ('MER002','Mercedes Benz','A200 Sedan',4080,15000,'yes'),
	  ('FOR001','Ford','Fiesta 1.0',7600,15000,'yes');

INSERT INTO Driver(DriverName,DriverAddress,DriverEmail,DriverMobile)
VALUES('Gabrielle Clarke','917 Heuval St Botshabelo Free State 9781','gorix10987@macauvpn.com',0837113269),
	  ('Geoffrey Franklin','1114 Dorp St Paarl Western Cape 7655','noceti8743@drlatvia.com',0847728052),
	  ('Fawn Cooke','2158 Prospect St Garsfontein Gauteng 0042','yegifav388@enamelme.com',0821966584),
	  ('Darlene Peters','2529 St.John Street Somerset West Western Cape 7110','mayeka4267@macauvpn.com',0841221244),
	  ('Vita Soto','1474 Wolmarans St Sundra Mpumalanga 2200','wegog55107@drlatvia.com',0824567924),
	  ('Opal Rehbein','697 Thutlwa St Letaba Limpopo 0870','yiyow34505@enpaypal,com',0826864938),
	  ('Vernon Hodgson','1935 Thutlwa St Letsitele Limpopo 0885','gifeh11935@enamelme.com',0855331446),
	  ('Crispin Wheatly','330 Sandown Rd Cape Town Western Cape 8018','likon78255@macauvpn.com',0838357945),
	  ('Melanie Cunningham','616 Loop St Atlantis Western Cape 7350','sehapeb835@macauvpn.com',0827329001),
	  ('Kevin Peay','814 Daffodil Dr elliotdale Eatsern Cape 5118','xajic53991@enpaypal.com',0832077149);

INSERT INTO ReturnCars(CarNo,InspectNO,DriverID,ReturnDate,ElapsedDate,Fine)
VALUES('HYU001','I101','1',2021-08-31,0,0),
	  ('HYU002','I101','1',2021-09-10,0,0),
	  ('FOR001','I101','2',2021-09-10,0,0),
	  ('BMW002','I102','5',2021-09-30,5,2500),
	  ('TOY002','I102','4',2021-10-31,2,1000),
	  ('MER001','I103','4',2021-10-15,1,500),
	  ('HYU002','I104','7',2022-02-10,0,0),
	  ('TOY003','I104','9',2021-08-31,0,0);
	
INSERT INTO Rentals(CarNo,InspectNO,DriverID,RentalFee,StartDate,EndDate)
VALUES('HYU001','I101','1',5000,2021-08-30,2021-08-31),
	  ('HYU002','I101','1',5000,2021-09-01,2021-09-10),
	  ('FOR001','I101','2',6500,2021-09-01,2021-09-10),
	  ('BMW002','I102','5',7000,2021-09-20,2021-09-25),
	  ('TOY002','I102','4',5000,2021-10-03,2021-10-31),
	  ('MER001','I103','4',8000,2021-10-05,2021-10-15),
	  ('HYU002','I104','7',5000,2021-12-01,2021-02-10),
	  ('TOY003','I104','9',5000,2021-08-10,2021-08-31);

	  SELECT * FROM Car;
	  ---------Question 5----------
SELECT * FROM Rentals
WHERE StartDate > 2021-08-01 
AND EndDate < 2021-10-30;

---------Question 6----------
SELECT * FROM Rentals
WHERE InspectNO LIKE 'I101';

---------Question 7----------
SELECT * FROM ReturnCars
WHERE CarNo LIKE 'TOY%';

---------Question 8----------
SELECT * FROM Rentals
WHERE CarNo LIKE 'HYU%';

---------Question 9----------
UPDATE Car
SET CarModel = 'Focus 1.0'
WHERE CarModel LIKE 'Fiesta 1.0';
SELECT * FROM Car;

---------Question 10----------
SELECT * FROM Car 
WHERE Avalaible LIKE 'yes';

---------Question 11----------
SELECT DISTINCT
	CarMake
FROM
	Car
ORDER BY
	CarMake

---------Question 12----------
SELECT * FROM Car
WHERE KmServ -KmTrav < 9000;